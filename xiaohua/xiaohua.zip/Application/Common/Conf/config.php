<?php
return array(
	//'配置项'=>'配置值'


  'DB_TYPE' => 'mysql', // 数据库类型
  'DB_HOST'=>'localhost',//设置主机
  'DB_NAME'=>'xiaohua',//设置数据库名
  'DB_USER'=>'root',  //设置用户名
  'DB_PWD'=>'',   //设置密码
  'DB_PORT'=>'3306',   //设置端口号
  'DB_CHARSET'=> 'utf8', // 字符集
  'DB_PREFIX'=>'x_',  //设置表前缀



);
